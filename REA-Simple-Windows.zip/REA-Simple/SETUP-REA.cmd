@echo off
setlocal
cd /d "%~dp0engine"
where node >nul 2>nul
if errorlevel 1 goto missing
where npm >nul 2>nul
if errorlevel 1 goto missing
node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit((a===22&&b>=19)||(a===24&&b>=11)||a>=26?0:1)"
if errorlevel 1 goto missing
echo Installing the included REA source's locked dependencies and building locally.
echo Internet access is required. Your other software and agent settings are not changed.
call npm ci
if errorlevel 1 goto failed
call npm run build:cached
if errorlevel 1 goto failed
echo Setup finished. Open START.cmd and select REA JavaScript analysis.
pause
exit /b 0
:missing
echo Install supported Node.js from https://nodejs.org/ manually, then rerun.
echo Required: Node 22.19+, 24.11+, or 26+. Node 23 and 25 are not supported.
pause
exit /b 1
:failed
echo Setup failed. Read the error above. Check your internet connection and retry.
echo Basic report still works with START.cmd.
pause
exit /b 1
