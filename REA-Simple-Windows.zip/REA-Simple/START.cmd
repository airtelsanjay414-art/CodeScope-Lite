@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 rea_simple.py
  if errorlevel 1 pause
  exit /b
)
where python >nul 2>nul
if not errorlevel 1 (
  python rea_simple.py
  if errorlevel 1 pause
  exit /b
)
echo Python 3 with Tkinter is required. Install from https://www.python.org/downloads/windows/
echo Enable Add Python to PATH during installation. Then reopen START.cmd.
pause
