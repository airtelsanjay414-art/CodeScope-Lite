"""REA Simple: dependency-free desktop front end for the included REA source."""
import hashlib
import json
import os
from pathlib import Path
import queue
import shutil
import subprocess
import tempfile
import threading
import time

ROOT = Path(__file__).resolve().parent
ENGINE = ROOT / 'engine'
LIMIT = 8 * 1024 * 1024


def basic_report(target):
    path = Path(target).expanduser().resolve(strict=True)
    report = {'tool': 'REA Simple basic inspection', 'path': str(path),
              'note': 'Metadata only. No code is executed; this is not decompilation.'}
    if path.is_file():
        size = path.stat().st_size
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            header = stream.read(16)
            digest.update(header)
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
        kind = 'Unknown / other'
        for magic, name in [(b'MZ', 'Windows executable family'),
                            (b'\x7fELF', 'ELF binary'), (b'PK\x03\x04', 'ZIP container'),
                            (b'%PDF', 'PDF document')]:
            if header.startswith(magic):
                kind = name
                break
        report.update(kind=kind, bytes=size, sha256=digest.hexdigest(),
                      extension=path.suffix, header_hex=header.hex())
    elif path.is_dir():
        entries = []
        with os.scandir(path) as scan:
            for item in scan:
                if len(entries) >= 200:
                    report['truncated'] = True
                    break
                entries.append({'name': item.name, 'type': 'link' if item.is_symlink()
                                else 'folder' if item.is_dir(follow_symlinks=False) else 'file'})
        report.update(kind='Folder', scope='Immediate children only, maximum 200',
                      entries=sorted(entries, key=lambda x: x['name'].lower()))
    else:
        raise ValueError('Choose a regular file or folder.')
    return json.dumps(report, indent=2, ensure_ascii=False)


def runtime_ready():
    return bool(shutil.which('node') and
                (ENGINE / 'dist/cli-runtime/cli.js').is_file())


def rea_report(target):
    path = Path(target).expanduser().resolve(strict=True)
    if not (path.is_dir() or path.suffix.lower() in ('.asar', '.js', '.mjs', '.cjs')):
        raise ValueError('REA JavaScript mode needs a JavaScript app folder, JS file or ASAR. '
                         'Use Basic report for other files. Native decompilation needs a provider.')
    if not runtime_ready():
        raise RuntimeError('REA engine is not built. Close this window, run SETUP-REA.cmd, '
                           'then open START.cmd again. Basic report works without REA setup.')
    command = [shutil.which('node'), str(ENGINE / 'scripts/rea.mjs'),
               'analyze-javascript-application', str(path), '--json']
    # Spool output to disk, retaining a bounded preview in the UI.
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        process = subprocess.Popen(command, cwd=ENGINE, stdout=out, stderr=err,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        try:
            process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            raise RuntimeError('Analysis exceeded 3 minutes. Try a smaller application folder.')
        out.seek(0)
        err.seek(0)
        result = out.read(LIMIT + 1)
        diagnostic = err.read(32768).decode('utf-8', errors='replace')
        if process.returncode:
            raise RuntimeError(diagnostic or result.decode('utf-8', errors='replace') or
                               'REA failed without diagnostic output.')
        if len(result) > LIMIT:
            raise RuntimeError('Report exceeds the 8 MiB desktop display limit. '
                               'Use the original CLI to save a larger report.')
        return result.decode('utf-8', errors='replace') or diagnostic or 'REA returned no output.'


def main():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    from tkinter.scrolledtext import ScrolledText
    app = tk.Tk()
    app.title('REA Simple — Local File Inspector')
    app.geometry('940x720')
    app.minsize(650, 500)
    app.configure(bg='#edf2f7')
    style = ttk.Style(app)
    style.theme_use('clam')
    style.configure('TButton', padding=10)
    style.configure('TLabel', background='#edf2f7', font=('Segoe UI', 10))
    style.configure('TFrame', background='#edf2f7')
    frame = ttk.Frame(app, padding=24)
    frame.pack(fill='both', expand=True)
    ttk.Label(frame, text='REA Simple', font=('Segoe UI', 26, 'bold')).pack(anchor='w')
    ttk.Label(frame, text='Choose a file. Understand the basics. Save your report.').pack(anchor='w', pady=(0, 18))
    ttk.Label(frame, text='1  Choose your file or application folder').pack(anchor='w')
    path = tk.StringVar()
    row = ttk.Frame(frame)
    row.pack(fill='x', pady=8)
    entry = ttk.Entry(row, textvariable=path)
    entry.pack(side='left', fill='x', expand=True, ipady=8)
    def pick(folder=False):
        selected = filedialog.askdirectory() if folder else filedialog.askopenfilename()
        if selected:
            path.set(selected)
    ttk.Button(row, text='File…', command=pick).pack(side='left', padx=5)
    ttk.Button(row, text='Folder…', command=lambda: pick(True)).pack(side='left')
    ttk.Label(frame, text='2  Select a report').pack(anchor='w', pady=(10, 5))
    mode = tk.StringVar(value='basic')
    ttk.Radiobutton(frame, text='Basic report — offline, no engine setup needed',
                    value='basic', variable=mode).pack(anchor='w', pady=3)
    ttk.Radiobutton(frame, text='REA JavaScript analysis — requires SETUP-REA.cmd first',
                    value='rea', variable=mode).pack(anchor='w', pady=3)
    status = tk.StringVar(value='Ready • REA engine ' + ('built' if runtime_ready() else 'needs optional setup'))
    actions = ttk.Frame(frame)
    actions.pack(fill='x', pady=12)
    messages = queue.Queue()
    report = ScrolledText(frame, font=('Consolas', 10), wrap='word', bg='#101b2c',
                          fg='#e0ecff', insertbackground='white', padx=15, pady=15)
    def show(value):
        report.configure(state='normal')
        report.delete('1.0', 'end')
        report.insert('1.0', value)
        report.configure(state='disabled')
    def run():
        if not path.get().strip():
            messagebox.showinfo('Choose a target', 'Select a file or folder first.')
            return
        target, selected_mode = path.get().strip(), mode.get()
        run_button.configure(state='disabled')
        save_button.configure(state='disabled')
        status.set('Working… Please wait. Large files may take longer.')
        show('Reading local data…')
        def worker():
            started = time.monotonic()
            try:
                result = basic_report(target) if selected_mode == 'basic' else rea_report(target)
                messages.put((True, result, time.monotonic() - started))
            except Exception as exc:
                messages.put((False, str(exc), time.monotonic() - started))
        threading.Thread(target=worker, daemon=True).start()
    def poll():
        try:
            ok, value, elapsed = messages.get_nowait()
        except queue.Empty:
            pass
        else:
            show(value)
            run_button.configure(state='normal')
            save_button.configure(state='normal' if ok else 'disabled')
            status.set(('Report ready' if ok else 'Could not complete — see details above') + f' • {elapsed:.1f}s')
        app.after(100, poll)
    def save():
        value = report.get('1.0', 'end-1c')
        try:
            json.loads(value)
            extension = '.json'
        except ValueError:
            extension = '.txt'
        dest = filedialog.asksaveasfilename(initialfile='REA-report' + extension,
                                            defaultextension=extension)
        if dest:
            try:
                Path(dest).write_text(value, encoding='utf-8')
                status.set('Saved: ' + dest)
            except OSError as exc:
                messagebox.showerror('Save failed', str(exc))
    run_button = ttk.Button(actions, text='Create report', command=run)
    run_button.pack(side='left')
    save_button = ttk.Button(actions, text='Save report…', command=save, state='disabled')
    save_button.pack(side='left', padx=8)
    ttk.Button(actions, text='Help', command=lambda: messagebox.showinfo('REA Simple',
        'BASIC: File type, size, SHA-256 or folder listing.\n\n'
        'REA: Analyze a local JavaScript application using the included original engine. '
        'Run SETUP-REA.cmd once with internet access first.\n\n'
        'No AI account is needed for these buttons. REA agent integration and native '
        'providers remain available through the original CLI.\n\n'
        'ಕನ್ನಡ: File ಅಥವಾ Folder ಆಯ್ಕೆ ಮಾಡಿ → Create report → Save report.')).pack(side='right')
    report.pack(fill='both', expand=True)
    show('Welcome!\n\n1. Click File or Folder.\n2. Keep Basic report selected to begin.\n3. Click Create report, then Save report.\n\n'
         'ಕನ್ನಡ: ಫೈಲ್ ಆಯ್ಕೆ ಮಾಡಿ → Create report ಒತ್ತಿ → ವರದಿ ಉಳಿಸಿ.\n\n'
         'Basic mode inspects metadata. Deep decompilation requires the original REA tools.')
    ttk.Label(frame, textvariable=status).pack(anchor='w', pady=(10, 0))
    def close():
        if str(run_button['state']) == 'disabled':
            messagebox.showinfo('Report in progress', 'Please wait for the current report before closing (REA timeout: 3 minutes).')
        else:
            app.destroy()
    app.protocol('WM_DELETE_WINDOW', close)
    poll()
    app.mainloop()


if __name__ == '__main__':
    main()
